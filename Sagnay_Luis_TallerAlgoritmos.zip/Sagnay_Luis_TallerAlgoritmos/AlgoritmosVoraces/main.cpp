#include "Mochila.h"

int main() {
    Articulo articulos[] = {    //Crear los objetos de la clase Articulo, con su pero y valor
        Articulo(4, 10),    //Rojo
        Articulo(3, 40),    //Azul
        Articulo(5, 30),    //Verde
        Articulo(2, 20)     //Amarillo
    };

    int n = sizeof(articulos) / sizeof(articulos[0]);  // Numero de articulos
    int capacidad = 8;  //Definir la capacidad de 8 kg
    Mochila mochila(capacidad);    //Crear un objeto mochila de la clase Mochila

    int gananciaMaxima = mochila.maximizarGanancia(articulos, n);
    int numeroIteraciones = mochila.obtenerNumeroIteraciones();

    cout << "La ganancia maxima que se puede obtener es: " << gananciaMaxima << " dolares" << endl;
    cout << "El numero total de iteraciones es: " << numeroIteraciones << endl;

    return 0;
}