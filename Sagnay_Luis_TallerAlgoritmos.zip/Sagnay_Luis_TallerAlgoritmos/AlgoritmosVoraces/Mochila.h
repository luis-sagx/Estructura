#ifndef ARTICULO_H
#define ARTICULO_H

#include "Articulo.h"

class Mochila {
public:
    int capacidad;
    int pDinamica[9];  //Arreglo para almacenar el máximo valor posible para cada peso hasta la capacidad
    int contadorIteraciones;

    Mochila(int c){ //Constructor para inicializar la mochila
        capacidad = c;
        int contadorIteraciones = 0;
        for (int i = 0; i <= capacidad; ++i) { //Inicializar el arreglo de pDinamica con ceros
            pDinamica[i] = 0;
        }
    }

    int maximizarGanancia(Articulo articulos[], int n);
    int obtenerNumeroIteraciones();
};

int Mochila::maximizarGanancia(Articulo articulos[], int n) {
        // Algoritmo voraz que permite repetir artículos
        for (int i = 1; i <= capacidad; i++) { // Iterar sobre todas las capacidades posibles desde 0 hasta la capacidad que es 8 kg
            for (int j = 1; j < n; j++) {   // Iterar sobre todos los articulos disponibles
                contadorIteraciones++;      //Incrementar el contador
                if (articulos[j].peso <= i) {   // Verificar si el articulo puede ser añadido a la mochila actual
                    int nuevoValor = pDinamica[i - articulos[j].peso] + articulos[j].valor; // Calcular el posible valor si se incluye el artículo
                    if (nuevoValor > pDinamica[i]) { //Actualiza la ganancia maxima si el nuevo valor es mayor
                        pDinamica[i] = nuevoValor;
                    }
                }
            }
        }
        // El valor máximo que se puede obtener con la capacidad de 8 kg
        return pDinamica[capacidad];
    }

    int Mochila::obtenerNumeroIteraciones() {
        return contadorIteraciones;     //Retorna el numero de iteraciones realizadas
    }


#endif