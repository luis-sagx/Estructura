#include <iostream>
using namespace std;

class Articulo {
public:
    int peso;
    int valor;

    Articulo(int p, int v){ // Constructor para inicializar un artículo
        peso = p;
        valor = v;
    }
};
