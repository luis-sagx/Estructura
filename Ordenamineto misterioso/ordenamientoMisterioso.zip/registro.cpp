#include "registro.h"

Registro::Registro(int valor) : dato(valor) {}
